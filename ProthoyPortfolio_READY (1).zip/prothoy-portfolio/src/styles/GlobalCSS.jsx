import { useEffect } from 'react';

// All website + admin CSS in one place
const GlobalCSS = () => {
  useEffect(()=>{
    if(!document.querySelector('meta[name="viewport"]')){
      const m=document.createElement('meta');
      m.name='viewport';
      m.content='width=device-width,initial-scale=1,viewport-fit=cover';
      document.head.prepend(m);
    }
  },[]);
  return (<style>{`
    @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600&family=DM+Mono:wght@400;500&display=swap');
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    :root{
      /* WEBSITE palette */
      --w-bg:#071229;--w-bg2:#091530;--w-bg3:#0c1a38;
      --w-blue:#00D4FF;--w-purple:#8B5CF6;--w-pink:#EC4899;
      --w-text:#fff;--w-text2:#eaeaea;--w-text3:#cfcfcf;--w-muted:#A1A1AA;
      --w-border:rgba(255,255,255,0.07);--w-border2:rgba(255,255,255,0.18);
      --fd:'Syne',sans-serif;--fb:'DM Sans',sans-serif;
      /* ADMIN palette */
      --a-bg:#07101f;--a-bg2:#0b1628;--a-bg3:#0f1e35;
      --a-s1:#142242;--a-s2:#192a50;
      --a-t1:#fff;--a-t2:#e2e8f0;--a-t3:#94a3b8;--a-t4:#64748b;
      --a-blue:#38bdf8;--a-purple:#a78bfa;--a-pink:#f472b6;--a-green:#34d399;--a-amber:#fbbf24;--a-red:#f87171;
      --a-grad:linear-gradient(135deg,#38bdf8,#a78bfa);
      --a-border:rgba(255,255,255,0.055);--a-border2:rgba(255,255,255,0.11);--a-border3:rgba(255,255,255,0.22);
      --afd:'Bricolage Grotesque',sans-serif;--afm:'DM Mono',monospace;
      --sidebar:220px;
    }
    html{scroll-behavior:smooth}
    body,#root{background:var(--w-bg);color:var(--w-text);font-family:var(--fb)}
    *{-webkit-font-smoothing:antialiased}
    button,input,textarea,select{font-family:var(--fb)}
    a{text-decoration:none;color:inherit}
    ::-webkit-scrollbar{width:3px;height:3px}
    ::-webkit-scrollbar-track{background:transparent}
    ::-webkit-scrollbar-thumb{background:rgba(0,212,255,0.3);border-radius:4px}

    /* ANIMATIONS */
    @keyframes toastIn{from{opacity:0;transform:translateX(20px) scale(0.9)}to{opacity:1;transform:translateX(0) scale(1)}}
    @keyframes fadeUp{from{opacity:0;transform:translateY(28px)}to{opacity:1;transform:translateY(0)}}
    @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
    @keyframes orbFloat{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-30px) scale(1.05)}}
    @keyframes cardFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
    @keyframes marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}
    @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}
    @keyframes spin{to{transform:rotate(360deg)}}

    /* ══════════ WEBSITE STYLES ══════════ */
    .w-root{background:var(--w-bg);min-height:100vh}

    /* ══════════════════════════════════════════════
       ULTRA-PREMIUM FLOATING GLASSMORPHISM NAVBAR
    ══════════════════════════════════════════════ */

    /* Keyframes */
    @keyframes navIn{
      from{opacity:0;transform:translateY(-32px) scale(0.97)}
      to{opacity:1;transform:translateY(0) scale(1)}
    }
    @keyframes glowPulse{
      0%,100%{opacity:0.55;transform:scaleX(1)}
      50%{opacity:1;transform:scaleX(1.08)}
    }
    @keyframes accentFlow{
      0%{background-position:0% 50%}
      100%{background-position:200% 50%}
    }
    @keyframes logoShimmer{
      0%{background-position:0% 50%}
      100%{background-position:300% 50%}
    }
    @keyframes glassSheen{
      0%{transform:translateX(-100%) skewX(-15deg);opacity:0}
      15%{opacity:1}
      85%{opacity:1}
      100%{transform:translateX(500%) skewX(-15deg);opacity:0}
    }
    @keyframes ambientGlow{
      0%,100%{opacity:0.6;transform:translate(-50%,-50%) scale(1)}
      50%{opacity:0.9;transform:translate(-50%,-50%) scale(1.12)}
    }
    @keyframes burgerLineTop{
      0%,100%{transform:translateY(0) rotate(0)}
    }

    /* ── OUTER WRAPPER: provides floating margin + glow ── */
    .nav-outer{
      position:fixed;top:0;left:0;right:0;z-index:900;
      pointer-events:none;
      padding:18px 20px 0;
      animation:navIn 1s cubic-bezier(0.22,1,0.36,1) both;
      transition:padding 0.5s cubic-bezier(0.4,0,0.2,1);
    }
    .nav-outer.sc{padding:12px 20px 0;}

    /* Ambient glow blob behind the navbar */
    .nav-outer::before{
      content:'';
      position:absolute;
      top:0;left:50%;
      transform:translate(-50%,-40%);
      width:70%;height:120px;
      background:radial-gradient(ellipse at center,
        rgba(0,180,255,0.22) 0%,
        rgba(100,60,255,0.16) 40%,
        transparent 75%
      );
      filter:blur(28px);
      pointer-events:none;
      z-index:0;
      animation:ambientGlow 6s ease-in-out infinite;
    }

    /* ── THE FLOATING NAV PILL ── */
    .nav{
      pointer-events:all;
      position:relative;
      display:flex;align-items:center;justify-content:space-between;
      padding:0 10px 0 22px;
      height:62px;
      border-radius:28px;
      overflow:hidden;

      /* Deep navy glass background */
      background:
        linear-gradient(160deg,
          rgba(6,14,40,0.82) 0%,
          rgba(4,11,32,0.88) 35%,
          rgba(5,10,30,0.92) 70%,
          rgba(8,14,42,0.85) 100%
        );
      backdrop-filter:blur(56px) saturate(200%) brightness(1.08);
      -webkit-backdrop-filter:blur(56px) saturate(200%) brightness(1.08);

      /* Layered border reflections */
      border:1px solid rgba(255,255,255,0.10);
      outline:1px solid rgba(0,180,255,0.08);
      outline-offset:-2px;

      /* Depth-shadow stack */
      box-shadow:
        /* top inner highlight */
        0 1px 0 rgba(255,255,255,0.18) inset,
        /* left-edge inner light */
        1px 0 0 rgba(255,255,255,0.06) inset,
        /* main depth shadow */
        0 20px 60px rgba(0,0,0,0.55),
        0 8px 32px rgba(0,0,0,0.40),
        /* cyan ambient glow */
        0 4px 32px rgba(0,180,255,0.12),
        /* purple ambient glow */
        0 0 60px rgba(100,60,255,0.10),
        /* outer border glow */
        0 0 0 1px rgba(0,180,255,0.06);

      transition:height 0.5s cubic-bezier(0.4,0,0.2,1),
                 box-shadow 0.5s ease,
                 background 0.5s ease;
      z-index:1;
    }
    .nav-outer.sc .nav{
      height:54px;
      background:
        linear-gradient(160deg,
          rgba(5,12,34,0.92) 0%,
          rgba(4,9,28,0.95) 50%,
          rgba(6,12,36,0.94) 100%
        );
      box-shadow:
        0 1px 0 rgba(255,255,255,0.22) inset,
        1px 0 0 rgba(255,255,255,0.06) inset,
        0 24px 72px rgba(0,0,0,0.65),
        0 6px 28px rgba(0,0,0,0.50),
        0 4px 32px rgba(0,180,255,0.15),
        0 0 64px rgba(100,60,255,0.12),
        0 0 0 1px rgba(0,180,255,0.08);
    }

    /* Glass sheen sweep */
    .nav::before{
      content:'';
      position:absolute;top:0;left:0;
      width:80px;height:100%;
      background:linear-gradient(90deg,
        transparent 0%,
        rgba(255,255,255,0.06) 40%,
        rgba(255,255,255,0.10) 50%,
        rgba(255,255,255,0.06) 60%,
        transparent 100%
      );
      animation:glassSheen 7s ease-in-out 2s infinite;
      pointer-events:none;z-index:0;
    }

    /* Gradient accent line — bottom edge */
    .nav::after{
      content:'';
      position:absolute;bottom:0;left:10%;right:10%;height:1.5px;
      background:linear-gradient(90deg,
        transparent 0%,
        #00cfff 20%,
        #7c4dff 50%,
        #b24dff 70%,
        transparent 100%
      );
      background-size:200% 100%;
      animation:accentFlow 4s linear infinite;
      border-radius:0 0 28px 28px;
      opacity:0.7;
      pointer-events:none;
    }

    /* ── LOGO ── */
    .nav-logo{
      font-family:var(--fd);font-size:25px;font-weight:800;letter-spacing:-0.06em;
      background:linear-gradient(120deg,
        #ffffff 0%,
        #a8d8ff 20%,
        #00cfff 35%,
        #ffffff 50%,
        #c084fc 65%,
        #ffffff 80%,
        #00cfff 100%
      );
      background-size:300% auto;
      -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
      animation:logoShimmer 4s linear infinite;
      transition:transform 0.35s cubic-bezier(0.34,1.56,0.64,1),filter 0.3s;
      cursor:pointer;flex-shrink:0;
      position:relative;z-index:2;
      /* Logo area padding for luxury spacing */
      padding:6px 12px 6px 6px;
    }
    .nav-logo:hover{
      transform:scale(1.08) translateY(-1px);
      filter:drop-shadow(0 0 12px rgba(0,200,255,0.6));
    }
    .nav-logo:active{transform:scale(0.97);}

    /* ── DESKTOP LINKS WRAPPER ── */
    .nav-links{
      display:flex;gap:1px;align-items:center;
      position:relative;z-index:2;
      /* Glass pill container for the links */
      background:rgba(255,255,255,0.032);
      border:1px solid rgba(255,255,255,0.065);
      border-radius:100px;
      padding:4px;
      box-shadow:0 1px 0 rgba(255,255,255,0.08) inset;
    }

    /* Individual nav link */
    .nav-link{
      font-size:11px;font-weight:700;letter-spacing:0.09em;text-transform:uppercase;
      color:rgba(255,255,255,0.55);
      background:none;border:none;
      padding:8px 15px;border-radius:100px;
      transition:all 0.3s cubic-bezier(0.34,1.56,0.64,1);
      cursor:pointer;position:relative;overflow:hidden;
      white-space:nowrap;
    }
    .nav-link::before{
      content:'';position:absolute;inset:0;border-radius:100px;opacity:0;
      background:linear-gradient(135deg,
        rgba(0,210,255,0.14) 0%,
        rgba(120,80,255,0.10) 60%,
        rgba(255,255,255,0.06) 100%
      );
      border:1px solid rgba(0,200,255,0.18);
      box-shadow:0 1px 0 rgba(255,255,255,0.12) inset;
      transition:opacity 0.25s;
    }
    /* Glow dot indicator */
    .nav-link::after{
      content:'';
      position:absolute;bottom:4px;left:50%;
      transform:translateX(-50%);
      width:0;height:2px;
      background:linear-gradient(90deg,#00cfff,#7c4dff);
      border-radius:2px;
      box-shadow:0 0 8px rgba(0,200,255,0.8);
      transition:width 0.35s cubic-bezier(0.34,1.56,0.64,1);
      opacity:0;
    }
    .nav-link:hover{
      color:#fff;
      transform:translateY(-1px);
    }
    .nav-link:hover::before{opacity:1;}
    .nav-link:hover::after{width:20px;opacity:1;}
    .nav-link:active{transform:translateY(0) scale(0.96);}

    /* ── CTA BUTTON — premium floating glass ── */
    .nav-cta{
      padding:10px 22px;margin-left:10px;
      border:none;border-radius:100px;
      color:#fff;font-size:11.5px;font-weight:800;letter-spacing:0.07em;text-transform:uppercase;
      cursor:pointer;position:relative;overflow:hidden;z-index:2;

      background:linear-gradient(135deg,
        rgba(0,180,255,0.9) 0%,
        rgba(90,50,220,0.9) 55%,
        rgba(170,50,200,0.88) 100%
      );
      border:1px solid rgba(255,255,255,0.22);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.30) inset,
        0 6px 28px rgba(0,160,255,0.50),
        0 3px 16px rgba(100,50,220,0.38),
        0 1px 4px rgba(0,0,0,0.40);
      transition:all 0.3s cubic-bezier(0.34,1.56,0.64,1);
    }
    /* Top-half gloss */
    .nav-cta::before{
      content:'';position:absolute;top:0;left:0;right:0;height:50%;
      background:linear-gradient(180deg,rgba(255,255,255,0.28) 0%,rgba(255,255,255,0.04) 100%);
      border-radius:100px 100px 0 0;pointer-events:none;z-index:1;
    }
    /* Shimmer sweep */
    .nav-cta::after{
      content:'';position:absolute;top:0;left:-80px;width:50px;height:100%;
      background:linear-gradient(90deg,transparent,rgba(255,255,255,0.40),transparent);
      transform:skewX(-18deg);
      animation:glassSheen 3.5s ease-in-out 0.5s infinite;
      z-index:2;
    }
    .nav-cta:hover{
      transform:translateY(-3px) scale(1.06);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.35) inset,
        0 14px 48px rgba(0,160,255,0.60),
        0 6px 28px rgba(100,50,220,0.50),
        0 2px 8px rgba(0,0,0,0.45);
    }
    .nav-cta:active{transform:translateY(0) scale(0.97);}

    /* ── MOBILE ── */
    @media(max-width:768px){
      .nav-links,.nav-cta{display:none}
      .nav-burger{display:flex!important}
      .nav{padding:0 10px 0 18px;height:56px;border-radius:24px;}
      .nav-outer{padding:14px 14px 0;}
      .nav-outer.sc{padding:10px 14px 0;}
    }

    /* ── BURGER — premium glass button ── */
    .nav-burger{
      display:none;align-items:center;justify-content:center;cursor:pointer;
      width:44px;height:44px;
      border-radius:14px;
      background:linear-gradient(145deg,
        rgba(255,255,255,0.08) 0%,
        rgba(0,160,255,0.06) 50%,
        rgba(80,50,200,0.08) 100%
      );
      border:1px solid rgba(255,255,255,0.12);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.14) inset,
        0 4px 16px rgba(0,0,0,0.30),
        0 2px 12px rgba(0,140,255,0.12);
      transition:all 0.28s cubic-bezier(0.34,1.56,0.64,1);
      position:relative;z-index:2;flex-shrink:0;
      color:rgba(255,255,255,0.85);
    }
    .nav-burger:hover{
      background:linear-gradient(145deg,
        rgba(255,255,255,0.13) 0%,
        rgba(0,160,255,0.10) 50%,
        rgba(100,60,230,0.12) 100%
      );
      border-color:rgba(0,180,255,0.28);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.20) inset,
        0 6px 24px rgba(0,0,0,0.38),
        0 2px 16px rgba(0,160,255,0.22);
      transform:scale(1.06) translateY(-1px);
      color:#fff;
    }
    .nav-burger:active{transform:scale(0.95);}
    .nav-burger svg{display:block;width:18px;height:18px;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;fill:none;}

    /* ── MOBILE NAV — ANIMATIONS ── */
    @keyframes luxOverlayIn{from{opacity:0}to{opacity:1}}
    @keyframes luxDrawerIn{from{opacity:0;transform:translateX(-24px) scale(0.98)}to{opacity:1;transform:translateX(0) scale(1)}}
    @keyframes luxCardUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    @keyframes luxSheen{0%{transform:translateX(-120%) skewX(-18deg)}100%{transform:translateX(500%) skewX(-18deg)}}

    /* ── OVERLAY BACKDROP ── */
    .mob-overlay{
      display:none;position:fixed;inset:0;z-index:9998;
      background:rgba(3,6,20,0.78);
      backdrop-filter:blur(8px);
      -webkit-backdrop-filter:blur(8px);
    }
    .mob-overlay.open{display:block;animation:luxOverlayIn 0.3s ease both;}

    /* ── DRAWER PANEL ── */
    .mob-menu{
      display:none;position:fixed;top:0;left:0;bottom:0;
      width:min(340px,90vw);z-index:9999;
      flex-direction:column;
      background:linear-gradient(180deg,#070E25 0%,#08112B 100%);
      backdrop-filter:blur(48px) saturate(160%);
      -webkit-backdrop-filter:blur(48px) saturate(160%);
      border-right:1px solid rgba(120,140,255,0.12);
      border-top-right-radius:28px;
      border-bottom-right-radius:28px;
      box-shadow:
        1px 0 0 rgba(120,140,255,0.08) inset,
        32px 0 80px rgba(0,0,0,0.65),
        0 0 0 1px rgba(0,0,0,0.5);
      overflow:hidden;
    }
    .mob-menu.open{display:flex;animation:luxDrawerIn 0.38s cubic-bezier(0.22,1,0.36,1) both;}

    /* Top edge gloss — no colour, pure white */
    .mob-menu::before{
      content:'';position:absolute;top:0;left:0;right:0;height:1px;
      background:linear-gradient(90deg,transparent,rgba(255,255,255,0.15) 40%,rgba(255,255,255,0.08) 70%,transparent);
      pointer-events:none;z-index:2;
    }
    /* Subtle ambient blue glow — top-left corner depth */
    .mob-menu::after{
      content:'';position:absolute;top:-120px;left:-80px;
      width:320px;height:320px;border-radius:50%;
      background:radial-gradient(circle,rgba(100,120,255,0.06) 0%,transparent 70%);
      pointer-events:none;
    }

    /* Empty placeholder — kept for compat */
    .mob-menu-bg{display:none;}

    /* ── DRAWER HEADER ── */
    .mob-header{
      padding:26px 22px 18px;
      border-bottom:1px solid rgba(120,140,255,0.10);
      display:flex;align-items:center;justify-content:space-between;
      position:relative;z-index:1;flex-shrink:0;
    }

    /* Logo — clean white, no gradient */
    .mob-logo{
      font-family:var(--fd);font-size:22px;font-weight:800;letter-spacing:-0.04em;
      color:#fff;
    }

    /* Availability pill */
    .mob-avail-pill{
      display:flex;align-items:center;gap:6px;
      padding:4px 10px 4px 6px;
      background:rgba(100,120,255,0.08);
      border:1px solid rgba(120,140,255,0.14);
      border-radius:100px;
      font-size:10px;font-weight:600;letter-spacing:0.08em;
      color:rgba(255,255,255,0.40);text-transform:uppercase;
    }
    .mob-avail-dot{width:6px;height:6px;border-radius:50%;background:rgba(160,175,255,0.6);}

    /* Close button — neutral, elegant */
    .mob-close{
      width:36px;height:36px;border-radius:11px;
      background:rgba(100,120,255,0.07);
      border:1px solid rgba(120,140,255,0.12);
      display:flex;align-items:center;justify-content:center;
      color:rgba(255,255,255,0.5);cursor:pointer;
      transition:background 0.22s,color 0.22s,transform 0.22s,border-color 0.22s;
      flex-shrink:0;
    }
    .mob-close:hover{
      background:rgba(100,120,255,0.15);
      border-color:rgba(120,140,255,0.25);
      color:rgba(255,255,255,0.9);
      transform:rotate(90deg) scale(1.05);
    }
    .mob-close svg{display:block;width:14px;height:14px;stroke:currentColor;stroke-width:2;stroke-linecap:round;fill:none;}

    /* ── NAV LINKS AREA ── */
    .mob-nav{
      flex:1;padding:14px 14px;overflow-y:auto;position:relative;z-index:1;
      display:flex;flex-direction:column;gap:5px;
      scrollbar-width:none;
    }
    .mob-nav::-webkit-scrollbar{display:none;}

    /* Section label */
    .mob-nav-label{
      font-size:9.5px;font-weight:600;letter-spacing:0.14em;text-transform:uppercase;
      color:rgba(255,255,255,0.2);padding:0 4px;margin-bottom:4px;
    }

    /* ── INDIVIDUAL NAV CARD ── */
    .mob-link{
      display:flex;align-items:center;gap:13px;
      width:100%;padding:13px 15px;
      background:rgba(16,26,61,0.7);
      border:1px solid rgba(120,140,255,0.12);
      cursor:pointer;text-align:left;
      position:relative;overflow:hidden;
      transition:background 0.22s,border-color 0.22s,transform 0.22s,box-shadow 0.22s;
      border-radius:17px;
      opacity:0;
      animation:luxCardUp 0.4s cubic-bezier(0.22,1,0.36,1) both;
    }
    /* Top edge gloss highlight */
    .mob-link::before{
      content:'';position:absolute;top:0;left:0;right:0;height:1px;
      background:linear-gradient(90deg,transparent 10%,rgba(140,160,255,0.14) 50%,transparent 90%);
      pointer-events:none;opacity:0;transition:opacity 0.22s;
    }
    /* Gloss layer inside card */
    .mob-link::after{
      content:'';position:absolute;top:0;left:0;right:0;height:45%;
      background:linear-gradient(180deg,rgba(100,120,255,0.05) 0%,transparent 100%);
      border-radius:17px 17px 0 0;pointer-events:none;
    }
    .mob-link:hover{
      background:rgba(20,33,75,0.85);
      border-color:rgba(120,140,255,0.22);
      transform:scale(1.02) translateY(-1px);
      box-shadow:0 8px 24px rgba(0,5,30,0.4),0 1px 0 rgba(120,140,255,0.12) inset;
    }
    .mob-link:hover::before{opacity:1;}

    /* ── ICON BOX — blue glass ── */
    .mob-link-icon{
      width:40px;height:40px;border-radius:12px;flex-shrink:0;
      display:flex;align-items:center;justify-content:center;
      background:rgba(100,120,255,0.09);
      border:1px solid rgba(120,140,255,0.15);
      color:rgba(255,255,255,0.70);
      transition:background 0.22s,border-color 0.22s,color 0.22s,transform 0.22s;
      position:relative;z-index:1;overflow:hidden;
      font-size:16px;
    }
    .mob-link-icon::after{
      content:'';position:absolute;top:0;left:0;right:0;height:50%;
      background:linear-gradient(180deg,rgba(140,160,255,0.10) 0%,transparent 100%);
      border-radius:12px 12px 0 0;pointer-events:none;
    }
    .mob-link-icon svg{display:block;width:17px;height:17px;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round;fill:none;position:relative;z-index:1;}
    .mob-link:hover .mob-link-icon{
      background:rgba(100,120,255,0.16);
      border-color:rgba(120,140,255,0.28);
      color:#fff;
      transform:scale(1.06);
    }

    /* Text group */
    .mob-link-text{display:flex;flex-direction:column;gap:2px;position:relative;z-index:1;flex:1;}
    .mob-link-label{
      font-family:var(--fd);font-size:15px;font-weight:700;
      color:#fff;letter-spacing:-0.02em;transition:color 0.2s;line-height:1;
    }
    .mob-link-sub{font-size:11px;color:rgba(255,255,255,0.32);font-weight:400;letter-spacing:0.01em;transition:color 0.22s;}
    .mob-link:hover .mob-link-sub{color:rgba(255,255,255,0.5);}

    /* Arrow — blue-tinted white */
    .mob-link-arrow{
      margin-left:auto;flex-shrink:0;position:relative;z-index:1;
      color:rgba(140,160,255,0.30);
      display:flex;align-items:center;
      transition:color 0.22s,transform 0.22s;
    }
    .mob-link-arrow svg{display:block;width:14px;height:14px;stroke:currentColor;stroke-width:2;stroke-linecap:round;fill:none;}
    .mob-link:hover .mob-link-arrow{color:rgba(180,195,255,0.85);transform:translateX(3px);}

    /* Divider */
    .mob-divider{
      height:1px;margin:4px 0;
      background:rgba(120,140,255,0.08);
      border-radius:1px;
    }

    /* Footer of drawer */
    .mob-footer{
      padding:14px 14px 26px;
      border-top:1px solid rgba(120,140,255,0.10);
      position:relative;z-index:1;flex-shrink:0;
    }
    .mob-footer-info{font-size:11px;color:rgba(255,255,255,0.18);margin-top:10px;text-align:center;letter-spacing:0.05em;}

    /* Hero */
    .w-hero{min-height:100vh;display:flex;align-items:center;position:relative;overflow:hidden;padding:120px 48px 80px}
    @media(max-width:900px){.w-hero{padding:96px 20px 72px}}
    .w-orb{position:absolute;border-radius:50%;filter:blur(80px);animation:orbFloat 8s ease-in-out infinite;pointer-events:none}
    .w-orb1{width:500px;height:500px;background:rgba(0,212,255,0.07);top:-100px;right:-100px}
    .w-orb2{width:400px;height:400px;background:rgba(139,92,246,0.09);bottom:-50px;left:-100px;animation-delay:3s}
    .w-orb3{width:300px;height:300px;background:rgba(236,72,153,0.06);top:40%;left:40%;animation-delay:5s}
    .w-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(139,92,246,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(139,92,246,0.04) 1px,transparent 1px);background-size:80px 80px}
    .w-hero-content{position:relative;z-index:2;max-width:900px}
    .w-badge{display:inline-flex;align-items:center;gap:8px;padding:8px 16px;border:1px solid var(--w-border2);border-radius:100px;background:rgba(255,255,255,0.05);backdrop-filter:blur(10px);font-size:12px;font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--w-muted);margin-bottom:32px;animation:fadeUp 0.8s ease 0.3s both}
    .w-badge-dot{width:6px;height:6px;border-radius:50%;background:var(--w-pink);box-shadow:0 0 8px var(--w-pink);animation:pulse 2s infinite}
    .w-h1{font-family:var(--fd);font-size:clamp(42px,7vw,96px);font-weight:800;line-height:1.0;letter-spacing:-0.04em;margin-bottom:28px;animation:fadeUp 0.8s ease 0.5s both}
    .w-h1 .acc{background:linear-gradient(135deg,var(--w-blue),var(--w-purple),var(--w-pink));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
    .w-sub{font-size:clamp(16px,2vw,20px);color:var(--w-muted);font-weight:300;max-width:580px;line-height:1.7;margin-bottom:48px;animation:fadeUp 0.8s ease 0.7s both}
    .w-btns{display:flex;gap:16px;flex-wrap:wrap;animation:fadeUp 0.8s ease 0.9s both}
    .w-btn1{padding:16px 36px;background:linear-gradient(135deg,var(--w-blue),var(--w-purple));border:none;border-radius:100px;color:#000;font-size:15px;font-weight:600;cursor:pointer;transition:all 0.3s}
    .w-btn1:hover{transform:translateY(-2px);box-shadow:0 20px 60px rgba(0,212,255,0.3)}
    .w-btn2{padding:16px 36px;background:transparent;border:1px solid var(--w-border2);border-radius:100px;color:var(--w-text2);font-size:15px;font-weight:500;cursor:pointer;transition:all 0.3s}
    .w-btn2:hover{border-color:var(--w-blue);color:var(--w-blue);transform:translateY(-2px)}
    .w-floats{position:absolute;right:5%;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:16px;z-index:2;animation:fadeUp 1s ease 1s both}
    @media(max-width:900px){.w-floats{display:none}}
    .w-float{padding:16px 20px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:16px;backdrop-filter:blur(24px);box-shadow:0 8px 32px rgba(0,0,0,0.3),inset 0 1px 0 rgba(255,255,255,0.1);font-size:13px;color:var(--w-text2);min-width:180px;animation:cardFloat 4s ease-in-out infinite}
    .w-float:nth-child(2){animation-delay:1.5s;margin-left:20px}
    .w-float:nth-child(3){animation-delay:3s}
    .w-fl{font-size:11px;color:var(--w-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.1em}
    .w-fv{font-family:var(--fd);font-size:22px;font-weight:700}
    .w-scroll{position:absolute;bottom:40px;left:48px;display:flex;align-items:center;gap:12px;font-size:11px;letter-spacing:0.15em;text-transform:uppercase;color:var(--w-muted);animation:fadeUp 0.8s ease 1.2s both}
    .w-scroll-line{width:40px;height:1px;background:var(--w-muted)}

    /* Marquee */
    .w-mq{border-top:1px solid rgba(255,255,255,0.07);border-bottom:1px solid rgba(255,255,255,0.07);background:linear-gradient(90deg,rgba(0,212,255,0.04),rgba(139,92,246,0.07),rgba(236,72,153,0.04));overflow:hidden;padding:16px 0}
    .w-mq-track{display:flex;gap:48px;white-space:nowrap;animation:marquee 30s linear infinite}
    .w-mq-item{display:flex;align-items:center;gap:16px;font-size:12px;letter-spacing:0.15em;text-transform:uppercase;color:var(--w-muted);flex-shrink:0}
    .w-mq-dot{width:4px;height:4px;border-radius:50%;background:var(--w-blue)}

    /* Stats */
    .w-stats{position:relative;padding:80px 48px 40px;background:linear-gradient(180deg,var(--w-bg),rgba(7,18,41,0.6) 50%,var(--w-bg))}
    @media(max-width:768px){.w-stats{padding:56px 20px 28px}}
    .w-stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);border-radius:20px;overflow:hidden;margin-bottom:80px;box-shadow:0 20px 60px rgba(0,0,0,0.3)}
    @media(max-width:768px){.w-stats-grid{grid-template-columns:repeat(2,1fr)}}
    .w-stat{padding:40px 32px;text-align:center;background:linear-gradient(135deg,rgba(7,20,46,0.9),rgba(9,21,48,0.95));transition:background 0.3s}
    .w-stat:hover{background:linear-gradient(135deg,rgba(22,25,61,0.95),rgba(7,20,46,1))}
    .w-stat-v{font-family:var(--fd);font-size:clamp(40px,4vw,64px);font-weight:800;background:linear-gradient(135deg,var(--w-blue),var(--w-purple));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .w-stat-l{font-size:13px;color:var(--w-muted);margin-top:8px;text-transform:uppercase;letter-spacing:0.1em}

    /* Section commons */
    .w-sec{padding:120px 48px;position:relative}
    @media(max-width:768px){.w-sec{padding:72px 20px}}
    .w-sl{font-size:11px;letter-spacing:0.2em;text-transform:uppercase;color:var(--w-blue);margin-bottom:16px;display:flex;align-items:center;gap:12px}
    .w-sl::before{content:'';width:32px;height:1px;background:var(--w-blue)}
    .w-st{font-family:var(--fd);font-size:clamp(36px,5vw,64px);font-weight:800;letter-spacing:-0.03em;line-height:1.1;margin-bottom:16px}
    .w-st .g{background:linear-gradient(135deg,var(--w-blue),var(--w-purple));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .w-ss{font-size:17px;color:var(--w-muted);max-width:500px;line-height:1.7;margin-bottom:64px}

    /* Services */
    .w-srv{position:relative;overflow:hidden;background:linear-gradient(135deg,rgba(0,212,255,0.03),transparent 40%,rgba(139,92,246,0.04) 60%,rgba(236,72,153,0.03)),var(--w-bg)}
    .w-srv::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(0,212,255,0.4),rgba(139,92,246,0.4),transparent)}
    .w-srv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:1px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:24px;overflow:hidden;box-shadow:0 24px 80px rgba(0,0,0,0.35)}
    .w-srv-card{padding:36px 32px;background:linear-gradient(135deg,rgba(7,18,41,0.95),rgba(9,21,48,0.95));position:relative;overflow:hidden;transition:background 0.4s}
    .w-srv-card:hover{background:linear-gradient(135deg,rgba(10,23,52,0.98),rgba(9,21,48,0.98))}
    .w-srv-icon{font-size:28px;margin-bottom:20px;display:inline-block}
    .w-srv-title{font-family:var(--fd);font-size:20px;font-weight:700;margin-bottom:12px}
    .w-srv-desc{font-size:14px;color:var(--w-muted);line-height:1.7;margin-bottom:24px}
    .w-srv-price{display:inline-block;padding:6px 16px;border:1px solid rgba(255,255,255,0.12);border-radius:100px;font-size:12px;color:#fff;font-weight:500;background:rgba(255,255,255,0.04)}

    /* ════════════════════════════════════════════════════════
       CINEMATIC PREMIUM PORTFOLIO — AWARD-WINNING DESIGN
    ════════════════════════════════════════════════════════ */

    /* ── KEYFRAMES ── */
    @keyframes auroraShift{
      0%  { transform:translate(0%,0%) rotate(0deg) scale(1); opacity:0.55; }
      25% { transform:translate(3%,-4%) rotate(3deg) scale(1.04); opacity:0.70; }
      50% { transform:translate(-2%,5%) rotate(-2deg) scale(0.97); opacity:0.60; }
      75% { transform:translate(-4%,-2%) rotate(4deg) scale(1.06); opacity:0.72; }
      100%{ transform:translate(0%,0%) rotate(0deg) scale(1); opacity:0.55; }
    }
    @keyframes auroraShift2{
      0%  { transform:translate(0%,0%) rotate(0deg) scale(1); opacity:0.45; }
      33% { transform:translate(-5%,3%) rotate(-4deg) scale(1.07); opacity:0.62; }
      66% { transform:translate(4%,-3%) rotate(3deg) scale(0.95); opacity:0.50; }
      100%{ transform:translate(0%,0%) rotate(0deg) scale(1); opacity:0.45; }
    }
    @keyframes auroraShift3{
      0%  { transform:translate(0%,0%) scale(1); opacity:0.30; }
      50% { transform:translate(2%,-6%) scale(1.1); opacity:0.48; }
      100%{ transform:translate(0%,0%) scale(1); opacity:0.30; }
    }
    @keyframes particleDrift{
      0%  { transform:translateY(0px) translateX(0px); opacity:0; }
      10% { opacity:1; }
      90% { opacity:0.7; }
      100%{ transform:translateY(-120px) translateX(30px); opacity:0; }
    }
    @keyframes streakMove{
      0%  { transform:translateX(-100%) skewX(-25deg); opacity:0; }
      10% { opacity:0.6; }
      90% { opacity:0.3; }
      100%{ transform:translateX(200vw) skewX(-25deg); opacity:0; }
    }
    @keyframes gridPulse{
      0%,100%{ opacity:0.025; }
      50%    { opacity:0.045; }
    }
    @keyframes scanLine{
      0%  { transform:translateY(-100%); }
      100%{ transform:translateY(200%); }
    }
    @keyframes cardReveal{
      from{ opacity:0; transform:translateY(24px); }
      to  { opacity:1; transform:translateY(0); }
    }
    @keyframes iconFloat{
      0%,100%{ transform:translateY(0px) scale(1); }
      50%    { transform:translateY(-6px) scale(1.04); }
    }
    @keyframes iconGlowPulse{
      0%,100%{ filter:drop-shadow(0 0 14px currentColor) drop-shadow(0 0 30px currentColor); opacity:0.7; }
      50%    { filter:drop-shadow(0 0 28px currentColor) drop-shadow(0 0 60px currentColor) drop-shadow(0 0 90px currentColor); opacity:1; }
    }
    @keyframes featPulse{
      0%,100%{ box-shadow:0 0 0 0 rgba(0,212,255,0.5), 0 0 12px rgba(0,212,255,0.3); }
      50%    { box-shadow:0 0 0 5px rgba(0,212,255,0), 0 0 20px rgba(0,212,255,0.5); }
    }
    @keyframes accentLineFlow{
      0%  { background-position:0% 50%; }
      100%{ background-position:300% 50%; }
    }
    @keyframes mouseGlowAppear{
      from{ opacity:0; }
      to  { opacity:1; }
    }
    @keyframes filterBtnIn{
      from{ opacity:0; transform:translateY(8px) scale(0.95); }
      to  { opacity:1; transform:translateY(0) scale(1); }
    }

    /* ════════════ SECTION SHELL ════════════ */
    .w-port-section-wrap{
      position:relative;
      overflow:hidden;
      /* Rich deep background — no flat black */
      background:
        radial-gradient(ellipse 120% 80% at 50% -20%, rgba(0,150,255,0.07) 0%, transparent 55%),
        radial-gradient(ellipse 80% 60% at 90% 110%, rgba(139,92,246,0.09) 0%, transparent 50%),
        radial-gradient(ellipse 70% 50% at 5% 80%, rgba(236,72,153,0.06) 0%, transparent 50%),
        linear-gradient(180deg, #050816 0%, #060a1c 30%, #071229 60%, #060c20 100%);
      isolation:isolate;
    }

    /* ── AURORA LAYER 1 — Cyan bloom, top-left ── */
    .w-port-aurora1{
      position:absolute;
      top:-30%;left:-15%;
      width:85%;height:80%;
      border-radius:50%;
      background:radial-gradient(ellipse at 40% 40%,
        rgba(0,180,255,0.22) 0%,
        rgba(0,120,255,0.12) 30%,
        rgba(60,0,200,0.07) 60%,
        transparent 75%
      );
      filter:blur(72px);
      mix-blend-mode:screen;
      pointer-events:none;
      animation:auroraShift 18s ease-in-out infinite;
      will-change:transform,opacity;
    }

    /* ── AURORA LAYER 2 — Purple mass, center-right ── */
    .w-port-aurora2{
      position:absolute;
      top:10%;right:-20%;
      width:75%;height:90%;
      border-radius:50%;
      background:radial-gradient(ellipse at 55% 45%,
        rgba(139,92,246,0.20) 0%,
        rgba(100,50,220,0.14) 35%,
        rgba(220,80,160,0.08) 65%,
        transparent 80%
      );
      filter:blur(80px);
      mix-blend-mode:screen;
      pointer-events:none;
      animation:auroraShift2 22s ease-in-out infinite;
      will-change:transform,opacity;
    }

    /* ── AURORA LAYER 3 — Pink accent, bottom-right ── */
    .w-port-aurora3{
      position:absolute;
      bottom:-25%;right:-10%;
      width:65%;height:70%;
      border-radius:50%;
      background:radial-gradient(ellipse at 45% 55%,
        rgba(236,72,153,0.16) 0%,
        rgba(180,50,200,0.10) 40%,
        transparent 70%
      );
      filter:blur(88px);
      mix-blend-mode:screen;
      pointer-events:none;
      animation:auroraShift3 26s ease-in-out infinite;
      will-change:transform,opacity;
    }

    /* ── CYBER GRID OVERLAY ── */
    .w-port-grid-bg{
      position:absolute;inset:0;
      background-image:
        linear-gradient(rgba(0,212,255,0.032) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,212,255,0.032) 1px, transparent 1px);
      background-size:80px 80px;
      pointer-events:none;z-index:1;
      animation:gridPulse 8s ease-in-out infinite;
      /* Fade at edges */
      mask-image:
        radial-gradient(ellipse 90% 70% at 50% 50%,
          rgba(0,0,0,0.9) 20%,
          rgba(0,0,0,0.4) 60%,
          transparent 80%
        );
      -webkit-mask-image:
        radial-gradient(ellipse 90% 70% at 50% 50%,
          rgba(0,0,0,0.9) 20%,
          rgba(0,0,0,0.4) 60%,
          transparent 80%
        );
    }

    /* ── DIAGONAL DOT MATRIX ── */
    .w-port-dots{
      position:absolute;inset:0;
      background-image:radial-gradient(circle, rgba(139,92,246,0.08) 1px, transparent 1px);
      background-size:32px 32px;
      background-position:16px 16px;
      pointer-events:none;z-index:1;
      opacity:0.6;
      mask-image:
        radial-gradient(ellipse 70% 60% at 80% 70%,
          black 0%, transparent 70%
        );
      -webkit-mask-image:
        radial-gradient(ellipse 70% 60% at 80% 70%,
          black 0%, transparent 70%
        );
    }

    /* ── LIGHT STREAK 1 ── */
    .w-port-streak1{
      position:absolute;
      top:18%;left:0;
      width:100%;height:1px;
      background:linear-gradient(90deg,
        transparent 0%,
        rgba(0,212,255,0) 20%,
        rgba(0,212,255,0.5) 50%,
        rgba(139,92,246,0.4) 65%,
        rgba(236,72,153,0.2) 80%,
        transparent 100%
      );
      pointer-events:none;z-index:2;
      animation:streakMove 14s linear 3s infinite;
      opacity:0;
    }
    /* ── LIGHT STREAK 2 ── */
    .w-port-streak2{
      position:absolute;
      top:65%;left:0;
      width:100%;height:1px;
      background:linear-gradient(90deg,
        transparent 0%,
        rgba(139,92,246,0) 15%,
        rgba(139,92,246,0.4) 45%,
        rgba(236,72,153,0.35) 60%,
        rgba(0,212,255,0.2) 80%,
        transparent 100%
      );
      pointer-events:none;z-index:2;
      animation:streakMove 18s linear 8s infinite;
      opacity:0;
    }

    /* ── SCAN LINE (cinematic) ── */
    .w-port-scan{
      position:absolute;
      left:0;right:0;
      height:180px;
      background:linear-gradient(180deg,
        transparent 0%,
        rgba(0,180,255,0.025) 40%,
        rgba(0,180,255,0.05) 50%,
        rgba(0,180,255,0.025) 60%,
        transparent 100%
      );
      pointer-events:none;z-index:2;
      animation:scanLine 12s linear 2s infinite;
      top:0;
    }

    /* ── MOUSE-REACTIVE GLOW (JS-driven via inline style) ── */
    .w-port-mouse-glow{
      position:absolute;
      width:600px;height:600px;
      border-radius:50%;
      background:radial-gradient(circle,
        rgba(0,180,255,0.07) 0%,
        rgba(139,92,246,0.05) 40%,
        transparent 70%
      );
      transform:translate(-50%,-50%);
      pointer-events:none;
      z-index:2;
      filter:blur(40px);
      transition:left 0.12s ease-out, top 0.12s ease-out;
      animation:mouseGlowAppear 1s ease both;
    }

    /* ── VOLUMETRIC VIGNETTE EDGES ── */
    .w-port-section-wrap::before{
      content:'';
      position:absolute;inset:0;
      background:
        radial-gradient(ellipse 100% 30% at 50% 0%, rgba(5,8,22,0.6) 0%, transparent 100%),
        radial-gradient(ellipse 100% 25% at 50% 100%, rgba(5,8,22,0.7) 0%, transparent 100%),
        radial-gradient(ellipse 20% 100% at 0% 50%, rgba(5,8,22,0.5) 0%, transparent 100%),
        radial-gradient(ellipse 20% 100% at 100% 50%, rgba(5,8,22,0.5) 0%, transparent 100%);
      pointer-events:none;z-index:3;
    }

    /* ── CONTENT Z-INDEX ── */
    .w-port-content{position:relative;z-index:10;}

    /* ════════════ FILTER BAR ════════════ */
    .w-port-filter{
      display:flex;gap:6px;flex-wrap:wrap;
      margin-bottom:56px;
      padding:6px;
      position:relative;z-index:10;
      /* No visible container — pure floating pills */
      background:transparent;
      border:none;
      width:100%;
    }
    .w-port-filter::before{ display:none; }

    .w-filter-btn{
      padding:10px 20px;
      border:1px solid rgba(255,255,255,0.08);
      border-radius:100px;
      background:rgba(7,18,41,0.75);
      color:rgba(255,255,255,0.48);
      font-family:var(--fb);font-size:11px;font-weight:600;
      letter-spacing:0.09em;text-transform:uppercase;
      cursor:pointer;
      backdrop-filter:blur(20px);
      -webkit-backdrop-filter:blur(20px);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.07) inset,
        0 4px 20px rgba(0,0,0,0.35);
      transition:
        color 0.26s ease,
        background 0.26s ease,
        border-color 0.26s ease,
        box-shadow 0.26s ease,
        transform 0.3s cubic-bezier(0.34,1.56,0.64,1);
      white-space:nowrap;
      position:relative;overflow:hidden;
      animation:filterBtnIn 0.5s cubic-bezier(0.22,1,0.36,1) both;
    }
    .w-filter-btn:hover{
      color:#fff;
      background:rgba(10,22,55,0.88);
      border-color:rgba(0,180,255,0.25);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.12) inset,
        0 6px 28px rgba(0,0,0,0.45),
        0 0 24px rgba(0,160,255,0.12);
      transform:translateY(-3px) scale(1.04);
    }
    .w-filter-btn.on{
      color:#fff;
      background:linear-gradient(135deg,
        rgba(0,180,255,0.92) 0%,
        rgba(100,50,220,0.90) 50%,
        rgba(200,60,180,0.88) 100%
      );
      border-color:rgba(255,255,255,0.20);
      box-shadow:
        0 1px 0 rgba(255,255,255,0.35) inset,
        0 8px 36px rgba(0,0,0,0.40),
        0 0 32px rgba(0,180,255,0.40),
        0 0 60px rgba(139,92,246,0.25),
        0 4px 16px rgba(0,120,255,0.30);
      text-shadow:0 1px 8px rgba(0,0,0,0.5);
      transform:translateY(-3px) scale(1.05);
    }
    /* Active button gloss */
    .w-filter-btn.on::before{
      content:'';
      position:absolute;top:0;left:0;right:0;height:50%;
      background:linear-gradient(180deg,rgba(255,255,255,0.22) 0%,rgba(255,255,255,0.04) 100%);
      border-radius:100px 100px 0 0;
      pointer-events:none;
    }

    /* ════════════ CARDS GRID ════════════ */
    .w-port-grid{
      display:grid;
      grid-template-columns:repeat(auto-fill,minmax(320px,1fr));
      gap:22px;
      position:relative;z-index:10;
    }
    @media(max-width:768px){.w-port-grid{grid-template-columns:1fr;gap:16px}}

    /* ════════════ INDIVIDUAL CARD ════════════ */
    .w-port-card{
      border-radius:20px;
      overflow:hidden;
      position:relative;
      cursor:pointer;
      animation:cardReveal 0.6s cubic-bezier(0.22,1,0.36,1) both;

      /* Deep glass — no flat dark box */
      background:
        linear-gradient(145deg,
          rgba(8,18,50,0.72) 0%,
          rgba(5,12,38,0.82) 40%,
          rgba(7,14,44,0.78) 70%,
          rgba(9,16,46,0.72) 100%
        );
      backdrop-filter:blur(28px) saturate(180%);
      -webkit-backdrop-filter:blur(28px) saturate(180%);

      /* Ultra-thin border system — no chunky outlines */
      border:1px solid rgba(255,255,255,0.075);
      border-top-color:rgba(255,255,255,0.13);
      border-left-color:rgba(255,255,255,0.09);

      box-shadow:
        /* Inner highlight */
        0 1px 0 rgba(255,255,255,0.09) inset,
        /* Core shadow */
        0 12px 48px rgba(0,0,0,0.55),
        0 4px 16px rgba(0,0,0,0.30),
        /* Subtle colour glow — very soft */
        0 0 0 1px rgba(0,100,255,0.03);

      transition:
        transform 0.50s cubic-bezier(0.34,1.56,0.64,1),
        border-color 0.40s ease,
        box-shadow 0.50s ease;
    }
    /* Shimmer sweep on hover */
    .w-port-card::after{
      content:'';
      position:absolute;top:0;left:0;
      width:80px;height:100%;
      background:linear-gradient(90deg,
        transparent 0%,
        rgba(255,255,255,0.07) 40%,
        rgba(255,255,255,0.10) 50%,
        rgba(255,255,255,0.07) 60%,
        transparent 100%
      );
      opacity:0;
      pointer-events:none;z-index:20;
      transition:opacity 0.3s;
    }
    .w-port-card:hover{
      transform:translateY(-12px) scale(1.018);
      border-color:rgba(255,255,255,0.14);
      border-top-color:rgba(0,200,255,0.28);
    }
    /* Dynamic shadow color matched to card accent (overridden via JS style) */
    .w-port-card:hover{
      box-shadow:
        0 1px 0 rgba(255,255,255,0.13) inset,
        0 32px 80px rgba(0,0,0,0.65),
        0 12px 40px rgba(0,0,0,0.40),
        0 0 0 1px rgba(0,160,255,0.08),
        0 0 80px rgba(0,120,255,0.08),
        0 0 120px rgba(139,92,246,0.06);
    }

    /* ── CARD THUMBNAIL AREA ── */
    .w-port-thumb{
      aspect-ratio:16/10;
      border-bottom:1px solid rgba(255,255,255,0.055);
      position:relative;overflow:hidden;
      display:flex;align-items:center;justify-content:center;
      /* Multi-layer mesh — unique per card via JS color wash on top */
      background:
        radial-gradient(ellipse 100% 90% at 50% 0%,   rgba(0,0,0,0) 0%, rgba(0,0,0,0) 100%),
        linear-gradient(145deg, #040c28 0%, #060f30 100%);
    }
    /* Noise grain texture */
    .w-port-thumb::before{
      content:'';position:absolute;inset:0;
      background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)' opacity='0.05'/%3E%3C/svg%3E");
      opacity:0.55;pointer-events:none;z-index:1;
    }
    /* Bottom cinematic fade into card body */
    .w-port-overlay{
      position:absolute;inset:0;z-index:2;
      background:linear-gradient(
        180deg,
        transparent 0%,
        transparent 35%,
        rgba(5,12,38,0.40) 70%,
        rgba(5,12,38,0.88) 100%
      );
    }

    /* Icon: float + dual-glow pulse */
    .w-port-icon{
      font-size:54px;
      position:relative;z-index:3;
      animation:iconFloat 5s ease-in-out infinite, iconGlowPulse 4s ease-in-out infinite;
      will-change:transform,filter;
    }
    /* Horizontal reflection line below icon */
    .w-port-icon-reflection{
      position:absolute;
      bottom:16%;left:50%;
      transform:translateX(-50%);
      width:48px;height:1px;
      background:linear-gradient(90deg,transparent,currentColor,transparent);
      opacity:0.2;z-index:3;
      filter:blur(1px);
    }

    /* ── FEATURED BADGE ── */
    .w-port-feat{
      position:absolute;top:14px;right:14px;z-index:4;
      padding:5px 14px;
      background:rgba(3,8,24,0.70);
      backdrop-filter:blur(20px);
      border:1px solid rgba(0,212,255,0.30);
      border-radius:100px;
      font-size:10px;font-weight:800;
      letter-spacing:0.12em;
      text-transform:uppercase;
      animation:featPulse 3s ease-in-out infinite;
    }

    /* ── CARD INFO ── */
    .w-port-info{
      padding:22px 24px 26px;
      position:relative;z-index:5;
    }
    /* Gradient accent bar top-left of info area */
    .w-port-info::before{
      content:'';
      position:absolute;top:0;left:24px;
      width:32px;height:2px;
      border-radius:2px;
      background:var(--w-port-accent, linear-gradient(90deg,#00D4FF,#8B5CF6));
      opacity:0.7;
    }

    .w-port-cat{
      font-size:9.5px;letter-spacing:0.20em;text-transform:uppercase;
      margin-bottom:10px;margin-top:10px;
      display:flex;align-items:center;gap:7px;
      font-weight:600;
    }
    .w-port-title{
      font-family:var(--fd);font-size:18px;font-weight:700;
      margin-bottom:6px;
      color:#fff;
      letter-spacing:-0.025em;
      line-height:1.25;
    }
    .w-port-meta{
      font-size:12px;
      color:rgba(161,161,170,0.65);
      display:flex;align-items:center;gap:6px;
    }
    .w-port-meta::before{
      content:'';
      display:inline-block;
      width:3px;height:3px;
      border-radius:50%;
      background:rgba(161,161,170,0.35);
    }
    .w-port-tags{display:flex;gap:6px;margin-top:18px;flex-wrap:wrap;}
    .w-port-tag{
      padding:4px 12px;
      border-radius:100px;
      border:1px solid rgba(255,255,255,0.07);
      font-size:10px;font-weight:500;
      color:rgba(255,255,255,0.38);
      background:rgba(255,255,255,0.04);
      letter-spacing:0.06em;
      text-transform:uppercase;
      transition:border-color 0.2s, color 0.2s;
    }
    .w-port-card:hover .w-port-tag{
      border-color:rgba(255,255,255,0.12);
      color:rgba(255,255,255,0.55);
    }

    /* Particles (JS-rendered absolute divs) */
    .w-port-particle{
      position:absolute;
      border-radius:50%;
      pointer-events:none;
      z-index:3;
      animation:particleDrift linear infinite;
      will-change:transform,opacity;
    }

    /* Reviews */
    .w-rev{position:relative;overflow:hidden;background:radial-gradient(ellipse 100% 60% at 50% 100%,rgba(139,92,246,0.1),transparent 55%),var(--w-bg)}
    .w-rev::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(139,92,246,0.5),rgba(236,72,153,0.4),transparent)}
    .w-rev-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:24px}
    .w-rev-card{padding:32px;background:linear-gradient(135deg,rgba(7,20,46,0.7),rgba(9,21,48,0.8));border:1px solid rgba(255,255,255,0.07);border-radius:20px;backdrop-filter:blur(20px);transition:transform 0.3s,border-color 0.3s;position:relative;overflow:hidden}
    .w-rev-card::before{content:'"';position:absolute;top:12px;right:20px;font-size:80px;line-height:1;font-family:Georgia,serif;color:rgba(139,92,246,0.08);pointer-events:none}
    .w-rev-card:hover{transform:translateY(-6px);border-color:rgba(255,255,255,0.22)}
    .w-rev-stars{color:#FFB800;font-size:16px;margin-bottom:16px;letter-spacing:2px}
    .w-rev-text{font-size:15px;color:var(--w-text3);line-height:1.75;margin-bottom:24px;font-style:italic}
    .w-rev-author{display:flex;align-items:center;gap:12px}
    .w-rev-av{width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,var(--w-blue),var(--w-purple));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:16px;color:#000;flex-shrink:0}
    .w-rev-name{font-family:var(--fd);font-size:15px;font-weight:600}
    .w-rev-role{font-size:12px;color:var(--w-muted)}

    /* About */
    .w-about-grid{display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;position:relative;z-index:1}
    @media(max-width:900px){.w-about-grid{grid-template-columns:1fr;gap:40px}}
    .w-about-photo{width:100%;aspect-ratio:3/4;border-radius:24px;background:linear-gradient(135deg,rgba(7,20,46,0.9),rgba(7,18,41,0.95));border:1px solid rgba(255,255,255,0.09);display:flex;align-items:center;justify-content:center;position:relative;box-shadow:0 32px 80px rgba(0,0,0,0.5)}
    .w-about-badge{position:absolute;bottom:-20px;right:-20px;padding:16px 20px;background:linear-gradient(135deg,rgba(7,18,41,0.9),rgba(9,21,48,0.95));border:1px solid rgba(255,255,255,0.14);border-radius:16px;backdrop-filter:blur(24px)}
    @media(max-width:900px){.w-about-badge{right:0;bottom:-10px}}
    .w-about-bn{font-family:var(--fd);font-size:32px;font-weight:800;background:linear-gradient(135deg,var(--w-blue),var(--w-purple));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .w-about-bl{font-size:12px;color:var(--w-muted)}
    .w-bio{font-size:16px;color:var(--w-text3);line-height:1.8;margin-bottom:28px}
    .w-skill-head{display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px;font-weight:500}
    .w-skill-track{height:3px;background:var(--w-bg3);border-radius:2px;overflow:hidden;margin-bottom:18px}
    .w-skill-fill{height:100%;border-radius:2px;transition:width 1.5s cubic-bezier(0.16,1,0.3,1)}

    /* Contact */
    .w-contact{position:relative;overflow:hidden;background:radial-gradient(ellipse 70% 60% at 100% 0%,rgba(0,212,255,0.08),transparent 50%),radial-gradient(ellipse 70% 60% at 0% 100%,rgba(139,92,246,0.07),transparent 50%),var(--w-bg)}
    .w-contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:80px;position:relative;z-index:1}
    @media(max-width:900px){.w-contact-grid{grid-template-columns:1fr;gap:40px}}
    .w-form{display:flex;flex-direction:column;gap:18px}
    .w-fg{display:flex;flex-direction:column;gap:7px}
    .w-fl{font-size:12px;letter-spacing:0.1em;text-transform:uppercase;color:var(--w-muted)}
    .w-fi{padding:15px 19px;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:12px;color:var(--w-text);font-family:var(--fb);font-size:15px;outline:none;transition:border-color 0.3s;width:100%}
    .w-fi:focus{border-color:rgba(255,255,255,0.28);box-shadow:0 0 0 3px rgba(255,255,255,0.04)}
    .w-fi::placeholder{color:var(--w-muted)}
    textarea.w-fi{resize:vertical;min-height:120px}
    .w-social-btn{display:flex;align-items:center;gap:16px;padding:16px 22px;background:linear-gradient(135deg,rgba(7,20,46,0.6),rgba(9,21,48,0.7));border:1px solid rgba(255,255,255,0.07);border-radius:12px;color:var(--w-text2);font-family:var(--fb);font-size:14px;font-weight:500;cursor:pointer;text-decoration:none;transition:all 0.3s;display:flex}
    .w-social-btn:hover{border-color:rgba(255,255,255,0.25);transform:translateX(6px)}
    .w-social-links{display:flex;flex-direction:column;gap:14px;margin-top:28px}
    .w-success{padding:14px 18px;background:rgba(0,212,255,0.06);border:1px solid rgba(0,212,255,0.2);border-radius:12px;color:var(--w-blue);font-size:14px;margin-bottom:6px}

    /* Footer */
    footer{padding:56px 48px;border-top:1px solid transparent;border-image:linear-gradient(90deg,transparent,rgba(139,92,246,0.4),rgba(0,212,255,0.3),transparent) 1;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:24px;background:linear-gradient(180deg,rgba(0,212,255,0.02),rgba(7,18,41,1) 30%)}
    @media(max-width:768px){footer{padding:36px 20px;flex-direction:column;text-align:center}}
    .w-footer-brand{font-family:var(--fd);font-size:18px;font-weight:800;background:linear-gradient(135deg,var(--w-blue),var(--w-purple));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .w-footer-txt{font-size:13px;color:var(--w-muted)}

    .w-scroll-prog{position:fixed;top:0;left:0;height:2px;background:linear-gradient(90deg,var(--w-blue),var(--w-purple));z-index:9999;transition:width 0.1s}

    /* ══════════ ADMIN STYLES ══════════ */
    .a-root{display:flex;height:100vh;overflow:hidden;background:var(--a-bg)}
    .a-sidebar{width:var(--sidebar);flex-shrink:0;display:flex;flex-direction:column;background:var(--a-bg2);border-right:1px solid var(--a-border);overflow:hidden;transition:width 0.3s cubic-bezier(0.4,0,0.2,1)}
    .a-sidebar.col{width:58px}
    .a-main{flex:1;display:flex;flex-direction:column;overflow:hidden}
    .a-topbar{height:56px;flex-shrink:0;display:flex;align-items:center;justify-content:space-between;padding:0 24px;background:rgba(7,16,31,0.85);backdrop-filter:blur(16px);border-bottom:1px solid var(--a-border)}
    .a-content{flex:1;overflow-y:auto;background:var(--a-bg)}
    .a-page{padding:28px;animation:fadeIn 0.3s ease both}
    .a-sb-logo{padding:18px 16px 14px;border-bottom:1px solid var(--a-border);flex-shrink:0}
    .a-sb-brand{font-family:var(--afd);font-size:17px;font-weight:800;letter-spacing:-0.02em;background:var(--a-grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;white-space:nowrap;overflow:hidden}
    .a-sb-sub{font-size:9px;color:var(--a-t4);font-family:var(--afm);letter-spacing:0.08em;margin-top:2px;white-space:nowrap}
    .a-sb-search{margin:10px 10px 0;position:relative;flex-shrink:0}
    .a-sb-search input{width:100%;background:var(--a-bg3);border:1px solid var(--a-border2);border-radius:8px;padding:7px 10px 7px 28px;font-size:12px;color:var(--a-t2);outline:none;transition:border-color 0.2s}
    .a-sb-search input:focus{border-color:var(--a-blue)}
    .a-sb-search input::placeholder{color:var(--a-t4)}
    .a-sb-si{position:absolute;left:9px;top:50%;transform:translateY(-50%);font-size:12px;color:var(--a-t4);pointer-events:none}
    .a-sb-nav{flex:1;overflow-y:auto;padding:8px 0}
    .a-sb-gl{font-size:8px;font-weight:700;letter-spacing:0.18em;text-transform:uppercase;color:var(--a-t4);padding:14px 18px 5px;opacity:0.7;white-space:nowrap;overflow:hidden}
    .a-sb-item{display:flex;align-items:center;gap:10px;padding:9px 14px;margin:1px 8px;border-radius:8px;font-size:12.5px;font-weight:500;color:var(--a-t3);background:none;border:none;text-align:left;width:calc(100% - 16px);cursor:pointer;transition:all 0.18s;position:relative;white-space:nowrap}
    .a-sb-item:hover{background:rgba(255,255,255,0.04);color:var(--a-t1)}
    .a-sb-item.on{background:linear-gradient(135deg,rgba(56,189,248,0.12),rgba(167,139,250,0.09));color:var(--a-blue);font-weight:600}
    .a-sb-item.on::before{content:'';position:absolute;left:-8px;top:50%;transform:translateY(-50%);width:3px;height:20px;background:var(--a-grad);border-radius:2px}
    .a-sb-icon{font-size:15px;width:18px;text-align:center;flex-shrink:0}
    .a-sb-badge{margin-left:auto;background:rgba(56,189,248,0.15);color:var(--a-blue);font-size:9px;font-weight:700;padding:2px 7px;border-radius:20px;flex-shrink:0}
    .a-sb-footer{border-top:1px solid var(--a-border);padding:12px 14px 10px;flex-shrink:0}
    .a-col-btn{width:100%;display:flex;align-items:center;gap:8px;padding:7px 6px;border-radius:8px;background:none;border:none;color:var(--a-t4);font-size:12px;cursor:pointer;transition:color 0.2s}
    .a-col-btn:hover{color:var(--a-t2)}
    .a-tb-title{font-family:var(--afd);font-size:16px;font-weight:700;letter-spacing:-0.01em;color:var(--a-t1)}
    .a-tb-search{display:flex;align-items:center;gap:8px;background:var(--a-bg3);border:1px solid var(--a-border2);border-radius:8px;padding:6px 14px;flex:1;max-width:320px}
    .a-tb-search input{background:none;border:none;outline:none;font-size:13px;color:var(--a-t2);width:100%}
    .a-tb-search input::placeholder{color:var(--a-t4)}
    .a-card{background:var(--a-bg2);border:1px solid var(--a-border);border-radius:14px;padding:20px 22px;margin-bottom:16px}
    .a-ct{font-family:var(--afd);font-size:13.5px;font-weight:700;color:var(--a-t2);margin-bottom:16px;letter-spacing:0.01em}
    .a-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:12px;margin-bottom:20px}
    .a-stat{background:var(--a-bg2);border:1px solid var(--a-border);border-radius:14px;padding:18px 20px;position:relative;overflow:hidden;cursor:default;transition:border-color 0.2s,transform 0.2s}
    .a-stat:hover{border-color:var(--a-border2);transform:translateY(-1px)}
    .a-stat-n{font-family:var(--afd);font-size:28px;font-weight:800;letter-spacing:-0.04em}
    .a-stat-l{font-size:11px;color:var(--a-t4);margin-top:5px;font-weight:500;text-transform:uppercase;letter-spacing:0.07em}
    .a-stat-t{font-size:11px;margin-top:8px;font-weight:600}
    .a-fg{display:flex;flex-direction:column;gap:6px}
    .a-fl{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.09em;color:var(--a-t4)}
    .a-fi{background:var(--a-bg3);border:1px solid var(--a-border2);border-radius:8px;padding:9px 13px;font-size:13px;color:var(--a-t1);outline:none;transition:border-color 0.2s,box-shadow 0.2s;width:100%}
    .a-fi:focus{border-color:var(--a-blue);box-shadow:0 0 0 3px rgba(56,189,248,0.1)}
    .a-fi::placeholder{color:var(--a-t4)}
    textarea.a-fi{min-height:88px;resize:vertical}
    select.a-fi{cursor:pointer}
    input[type=color].a-fi{padding:4px 6px;height:40px;cursor:pointer}
    .a-bp{padding:9px 20px;background:var(--a-grad);border:none;border-radius:40px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;transition:opacity 0.2s,transform 0.15s;white-space:nowrap;display:inline-flex;align-items:center;gap:8px}
    .a-bp:hover{opacity:0.85;transform:translateY(-1px)}
    .a-bs{padding:9px 18px;background:var(--a-bg3);border:1px solid var(--a-border2);border-radius:8px;color:var(--a-t3);font-size:13px;font-weight:500;cursor:pointer;transition:all 0.18s;white-space:nowrap}
    .a-bs:hover{background:var(--a-s1);color:var(--a-t1)}
    .a-bsm{padding:5px 13px;background:var(--a-bg3);border:1px solid var(--a-border2);border-radius:8px;color:var(--a-t3);font-size:11.5px;font-weight:500;cursor:pointer;transition:all 0.15s;white-space:nowrap}
    .a-bsm:hover{background:var(--a-s1);color:var(--a-t1)}
    .a-bd{background:rgba(248,113,113,0.08)!important;border-color:rgba(248,113,113,0.25)!important;color:var(--a-red)!important}
    .a-bd:hover{background:rgba(248,113,113,0.16)!important}
    .a-tog{position:relative;width:36px;height:19px;flex-shrink:0}
    .a-tog input{opacity:0;width:0;height:0}
    .a-tog-sl{position:absolute;inset:0;cursor:pointer;border-radius:20px;background:var(--a-bg3);border:1px solid var(--a-border2);transition:all 0.22s}
    .a-tog-sl::before{content:'';position:absolute;width:13px;height:13px;left:2px;top:2px;border-radius:50%;background:var(--a-t4);transition:all 0.22s}
    input:checked+.a-tog-sl{background:linear-gradient(135deg,var(--a-blue),var(--a-purple));border-color:transparent}
    input:checked+.a-tog-sl::before{transform:translateX(17px);background:#fff}
    .a-badge{display:inline-flex;align-items:center;padding:2px 9px;border-radius:20px;font-size:10.5px;font-weight:600}
    .a-bb{background:rgba(56,189,248,0.12);color:var(--a-blue)}
    .a-bp2{background:rgba(167,139,250,0.12);color:var(--a-purple)}
    .a-bg{background:rgba(52,211,153,0.12);color:var(--a-green)}
    .a-br{background:rgba(248,113,113,0.12);color:var(--a-red)}
    .a-tbl{width:100%;border-collapse:collapse;font-size:12.5px}
    .a-tbl th{padding:9px 14px;text-align:left;font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--a-t4);border-bottom:1px solid var(--a-border);white-space:nowrap}
    .a-tbl td{padding:11px 14px;border-bottom:1px solid var(--a-border);color:var(--a-t2);vertical-align:middle}
    .a-tbl tr:last-child td{border-bottom:none}
    .a-tbl tr:hover td{background:rgba(255,255,255,0.018)}
    .a-empty{text-align:center;padding:44px 0;color:var(--a-t4);font-size:13px}
    .a-g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    .a-g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
    .a-modal-bd{position:fixed;inset:0;background:rgba(0,0,0,0.65);backdrop-filter:blur(6px);z-index:1000;display:flex;align-items:center;justify-content:center}
    .a-modal{background:var(--a-bg2);border:1px solid var(--a-border2);border-radius:20px;padding:32px;width:520px;max-width:94vw;max-height:90vh;overflow-y:auto;box-shadow:0 32px 80px rgba(0,0,0,0.7);animation:fadeIn 0.3s ease}
    .a-modal-title{font-family:var(--afd);font-size:18px;font-weight:800;margin-bottom:24px;letter-spacing:-0.01em}
    .a-av{width:32px;height:32px;border-radius:50%;background:var(--a-grad);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0}
    .a-act-row{display:flex;align-items:flex-start;gap:12px;padding:9px 0;border-bottom:1px solid var(--a-border)}
    .a-act-row:last-child{border-bottom:none}
    .a-dot{width:8px;height:8px;border-radius:50%;margin-top:4px;flex-shrink:0}
    .a-sr-drop{position:absolute;top:calc(100% + 6px);left:0;right:0;background:var(--a-bg2);border:1px solid var(--a-border2);border-radius:14px;box-shadow:0 16px 40px rgba(0,0,0,0.5);z-index:200;overflow:hidden;max-height:300px;overflow-y:auto}
    .a-sr-item{display:flex;align-items:center;gap:12px;padding:10px 16px;cursor:pointer;transition:background 0.15s;font-size:13px}
    .a-sr-item:hover{background:var(--a-s1)}
    .a-sr-cat{font-size:10px;color:var(--a-t4);font-family:var(--afm);margin-left:auto;flex-shrink:0}
    .a-hl{background:rgba(251,191,36,0.25);color:var(--a-amber);border-radius:2px;padding:0 1px}
    .a-live-dot{width:7px;height:7px;border-radius:50%;background:var(--a-green);box-shadow:0 0 6px rgba(52,211,153,0.6);animation:pulse 2s infinite}
    .a-pill{display:flex;align-items:center;gap:8px;padding:5px 12px 5px 5px;background:var(--a-bg3);border:1px solid var(--a-border);border-radius:40px;cursor:pointer}
    .a-chart-bars{display:flex;flex-direction:column;gap:14px}
    .a-chart-row{display:flex;align-items:center;gap:12px}
    .a-chart-lbl{width:140px;font-size:12.5px;color:var(--a-t3);flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .a-chart-track{flex:1;height:5px;background:var(--a-bg3);border-radius:5px;overflow:hidden}
    .a-chart-fill{height:100%;border-radius:5px;transition:width 1s ease}
    .a-chart-val{width:38px;text-align:right;font-size:11px;color:var(--a-t4);font-family:var(--afm)}
    /* Login */
    .a-login-page{height:100vh;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse 90% 60% at 50% -5%,rgba(56,189,248,0.08),transparent 55%),radial-gradient(ellipse 60% 50% at 90% 80%,rgba(167,139,250,0.09),transparent 50%),var(--a-bg);position:relative;overflow:hidden}
    .a-login-page::before{content:'';position:absolute;inset:0;background-image:radial-gradient(circle at 1px 1px,rgba(56,189,248,0.05) 1px,transparent 0);background-size:48px 48px}
    .a-login-card{width:380px;padding:48px 44px;background:rgba(11,22,40,0.9);border:1px solid var(--a-border3);border-top-color:rgba(255,255,255,0.4);border-radius:24px;backdrop-filter:blur(24px);box-shadow:0 40px 100px rgba(0,0,0,0.7),0 2px 0 rgba(255,255,255,0.25) inset}
    .a-login-brand{font-family:var(--afd);font-size:22px;font-weight:800;letter-spacing:-0.03em;background:var(--a-grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
    .a-login-err{font-size:12px;color:var(--a-red);padding:10px 14px;background:rgba(248,113,113,0.07);border:1px solid rgba(248,113,113,0.2);border-radius:8px;margin-bottom:14px}
    .a-spin{display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,0.2);border-top-color:#fff;border-radius:50%;animation:spin 0.7s linear infinite}

    /* ═══════════════════════════════════════════════════════
       COMPREHENSIVE RESPONSIVE — MOBILE & TABLET
    ═══════════════════════════════════════════════════════ */

    /* Hero — mobile */
    @media(max-width:640px){
      .w-hero{padding:100px 18px 64px;min-height:100svh;align-items:flex-start}
      .w-h1{font-size:clamp(32px,10vw,50px);margin-bottom:18px;line-height:1.05}
      .w-sub{font-size:15px;margin-bottom:32px;max-width:100%}
      .w-btns{flex-direction:column;gap:12px;width:100%}
      .w-btn1,.w-btn2{width:100%;padding:15px 24px;text-align:center;font-size:14px}
      .w-scroll{display:none}
      .w-badge{font-size:10px;padding:6px 12px}
      .w-orb1{width:260px;height:260px;top:-50px;right:-50px}
      .w-orb2{width:200px;height:200px;bottom:-20px;left:-50px}
      .w-orb3{display:none}
    }
    @media(max-width:380px){
      .w-h1{font-size:28px}
      .w-badge{font-size:9px}
    }

    /* Stats — mobile */
    @media(max-width:640px){
      .w-stats{padding:40px 16px 20px}
      .w-stats-grid{grid-template-columns:repeat(2,1fr);margin-bottom:48px}
      .w-stat{padding:22px 14px}
      .w-stat-v{font-size:clamp(26px,7vw,40px)}
      .w-stat-l{font-size:10px}
    }

    /* Section commons — mobile */
    @media(max-width:640px){
      .w-sec{padding:56px 18px}
      .w-st{font-size:clamp(26px,7.5vw,40px)}
      .w-ss{font-size:14px;margin-bottom:36px}
    }

    /* Services — mobile 1-col, tablet 2-col */
    @media(max-width:640px){
      .w-srv-grid{grid-template-columns:1fr;border-radius:16px}
      .w-srv-card{padding:24px 20px}
      .w-srv-icon{font-size:22px;margin-bottom:12px}
      .w-srv-title{font-size:16px}
      .w-srv-desc{font-size:13px;margin-bottom:0}
    }
    @media(min-width:641px) and (max-width:960px){
      .w-srv-grid{grid-template-columns:repeat(2,1fr)}
    }

    /* Portfolio filter bar — horizontal scroll on mobile */
    @media(max-width:640px){
      .w-port-filter{flex-wrap:nowrap;overflow-x:auto;padding-bottom:8px;-webkit-overflow-scrolling:touch;scrollbar-width:none;justify-content:flex-start;gap:8px}
      .w-port-filter::-webkit-scrollbar{display:none}
      .w-port-filter::before{display:none}
      .w-filter-btn{flex-shrink:0;font-size:11px;padding:7px 14px}
      .w-port-grid{grid-template-columns:1fr;gap:14px}
      .w-port-section-wrap{padding:56px 18px}
      .w-port-info{padding:16px 16px 20px}
      .w-port-icon{font-size:38px}
      .w-port-title{font-size:15px}
      .w-port-tags{margin-top:10px}
      .w-port-card:hover{transform:translateY(-4px) scale(1.008)}
    }
    @media(min-width:641px) and (max-width:960px){
      .w-port-grid{grid-template-columns:repeat(2,1fr)}
      .w-port-section-wrap{padding:72px 32px}
    }

    /* Reviews — mobile */
    @media(max-width:640px){
      .w-rev-grid{grid-template-columns:1fr;gap:14px}
      .w-rev-card{padding:20px 18px}
      .w-rev-text{font-size:14px;margin-bottom:18px}
      .w-rev-stars{font-size:14px}
    }
    @media(min-width:641px) and (max-width:960px){
      .w-rev-grid{grid-template-columns:repeat(2,1fr)}
    }

    /* About — mobile */
    @media(max-width:640px){
      .w-about-grid{gap:28px}
      .w-about-photo{aspect-ratio:4/3;border-radius:16px}
      .w-about-badge{right:8px;bottom:-6px;padding:10px 12px}
      .w-about-bn{font-size:20px}
      .w-bio{font-size:15px}
    }
    @media(min-width:641px) and (max-width:960px){
      .w-about-grid{gap:48px}
    }

    /* Contact — mobile (font-size 16px on inputs to prevent iOS zoom) */
    @media(max-width:640px){
      .w-contact-grid{gap:28px}
      .w-fi{font-size:16px;padding:13px 15px}
      textarea.w-fi{min-height:96px}
      .w-social-btn{padding:12px 14px;font-size:13px;gap:12px}
      .w-social-links{gap:10px;margin-top:20px}
    }

    /* Footer — mobile */
    @media(max-width:480px){
      footer{padding:28px 18px;gap:14px}
      .w-footer-brand{font-size:16px}
    }

    /* Marquee — faster on mobile */
    @media(max-width:640px){
      .w-mq-track{animation-duration:18s}
      .w-mq-item{gap:10px;font-size:11px}
      .w-mq{padding:12px 0}
    }

    /* Aurora/particle — reduce blur on mobile for GPU perf */
    @media(max-width:640px){
      .w-port-aurora1,.w-port-aurora2,.w-port-aurora3{filter:blur(40px);animation-duration:28s}
      .w-port-particle{display:none}
    }

    /* Global touch optimisations */
    @media(max-width:900px){
      html{-webkit-overflow-scrolling:touch}
      *{-webkit-tap-highlight-color:transparent}
      .w-srv-card:hover,.w-rev-card:hover{transform:none} /* no hover on touch */
    }

    /* Tablet (641–1024) general */
    @media(min-width:641px) and (max-width:1024px){
      .w-sec{padding:80px 32px}
      .w-hero{padding:96px 32px 64px}
      .w-stats{padding:56px 32px 28px}
      footer{padding:44px 32px}
    }
  `}</style>);
};


export { GlobalCSS };
